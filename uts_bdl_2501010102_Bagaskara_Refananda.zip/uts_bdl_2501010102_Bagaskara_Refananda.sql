-- soal 1a --
create database uts_bdl_2501010102;

-- soal 1b --
use uts_bdl_2501010102;

create table destinasi (
	id_destinasi char(4),
	nama_destinasi varchar(50) not null,
	kabupaten varchar(30) not null,
	harga_tiket int not null,
	primary key(id_destinasi)
);

create table paket_tur (
	id_paket char(4),
	id_destinasi char(4) not null,
	nama_paket varchar(50) unique not null,
	harga int not null,
	durasi_jam int,
	primary key(id_paket),
	foreign key(id_destinasi) references destinasi(id_destinasi)
);

create table wisatawan(
	id_wisatawan char(5),
	nama varchar(50) not null,
	asal_negara varchar(30) not null,
	email varchar(50) unique,
	primary key(id_wisatawan)
);

create table pemesanan(
	id_pesan int auto_increment,
	id_wisatawan char(5) not null,
	id_paket char(4) not null,
	tgl_tur date not null,
	jumlah_orang int not null,
	status varchar(10) not null default 'pending',
	primary key(id_pesan),
	foreign key(id_wisatawan) references wisatawan(id_wisatawan),
	foreign key(id_paket) references paket_tur(id_paket)
);

-- soal 1c --
alter table destinasi
add rating decimal(2,1)

-- soal 2a --
INSERT INTO destinasi(id_destinasi,nama_destinasi,kabupaten,harga_tiket,rating) VALUES 
('D001','Tanah Lot','Tabanan',30000,null),
('D002','Ulun Danu Beratan','Tabanan',50000,null),
('D003','Tirta Empul','Gianyar',50000,null),
('D004','Goa Gajah','Gianyar',50000,null),
('D005','Desa Panglipuran','Bangli',25000,null),
('D006','Pura Besakih','Karangasem',60000,null),
('D007','Jatiluwih','Tabanan',50000,null);

INSERT INTO paket_tur(id_paket,nama_paket,id_destinasi,harga,durasi_jam) VALUES 
('P001','Sunset Tanah Lot','D001',350000,5),
('P002','Bedugul Lake Tour','D002',450000,8),
('P003','Ubud Water Temple','D003',400000,6),
('P004','Ubud Heritage Walk','D004',300000,4),
('P005','Panglipuran Culture Trip','D005',375000,6),
('P006','Besakih Spiritual Journey','D006',500000,8),
('P007','Tanah Lot Photo Tour','D001',250000,3);

INSERT INTO wisatawan(id_wisatawan,nama,asal_negara,email) VALUES 
('W001','Made Ayu','Indonesia','made.ayu@gmail.com'),
('W002','John Smith','Australia','john.s@gmail.com'),
('W003','Sarah Lee','Singapura','sarah.lee@gmail.com'),
('W004','Kenji Tanaka','Jepang','kenji.t@gmail.com'),
('W005','Putu Arya','Indonesia','putu.arya@gmail.com'),
('W006','Emma Brown','Australia','emma.b@gmail.com'),
('W007','Li Wei','Tiongkok','li.wei@gmail.com'),
('W008','Komang Sari','Indonesia','komang.s@gmail.com');

INSERT INTO pemesanan(id_pesan,id_wisatawan,id_paket,tgl_tur,jumlah_orang,status) VALUES 
('1','W001','P001','2026-09-05',2,'Lunas'),
('2','W002','P003','2026-09-12',4,'Lunas'),
('3','W003','P002','2026-09-20',2,'Batal'),
('4','W004','P004','2026-10-02',3,'Lunas'),
('5','W002','P001','2026-10-03',4,'Lunas'),
('6','W005','P005','2026-10-10',5,'Lunas'),
('7','W006','P003','2026-10-15',2,'Pending'),
('8','W004','P002','2026-10-18',1,'Lunas'),
('9','W007','P007','2026-10-25',3,'Lunas'),
('10','W001','P004','2026-11-01',2,'Lunas'),
('11','W006','P001','2026-11-07',6,'Lunas'),
('12','W003','P005','2026-11-09',2,'Pending');

-- soal 2b --
UPDATE destinasi
SET harga_tiket = 30000
WHERE id_destinasi = 'D005';

-- soal 2c --
UPDATE pemesanan
SET harga_tiket = 'Lunas'
WHERE id_pesan = '12' ;

-- soal 2d --
DELETE FROM pemesanan WHERE status='Batal'

-- soal 2e --
INSERT INTO wisatawan (id_wisatawan, nama, asal_negara, email)
VALUES ('W0009', 'Anna Schmidt', 'Jerman', 'anna.s@gmail.com');

-- soal 2f --
-- INSERT INTO wisatawan VALUES --
-- ('W0010','Budi Santoso','Indonesia','made.ayu@gmail.com') --
-- Tidak dapat bekerja karena email bersifat unique, sehingga tidak bisa menambah data yang sama di salah satu kolom meskipun kolom lain sudah berbeda --

-- soal 3a --
SELECT nama_paket, harga 
FROM paket_tur 
WHERE harga BETWEEN 300000 AND 450000 
ORDER BY harga ASC;

-- soal 3b --
SELECT id_wisatawan, nama 
FROM wisatawan 
WHERE nama LIKE '%an%' 
ORDER BY nama ASC;

-- soal 3c --
SELECT id_pesan, id_wisatawan, jumlah_orang 
FROM pemesanan 
ORDER BY jumlah_orang DESC, id_pesan ASC 
LIMIT 3;

-- soal 3d --
SELECT id_pesan, tgl_tur, status 
FROM pemesanan 
WHERE status = 'Pending';

-- soal 4a --
SELECT wisatawan.nama, paket_tur.nama_paket, pemesanan.tgl_tur
FROM pemesanan
JOIN wisatawan ON pemesanan.id_wisatawan = wisatawan.id_wisatawan
JOIN paket_tur ON pemesanan.id_paket = paket_tur.id_paket
WHERE pemesanan.status = 'Lunas'
ORDER BY pemesanan.tgl_tur ASC;

-- soal 4b --
SELECT paket_tur.nama_paket, destinasi.nama_destinasi, destinasi.kabupaten
FROM paket_tur
INNER JOIN destinasi ON paket_tur.id_destinasi = destinasi.id_destinasi
WHERE destinasi.kabupaten = 'Gianyar'
ORDER BY paket_tur.nama_paket ASC;

-- soal 4c --
SELECT wisatawan.id_wisatawan, wisatawan.nama
FROM wisatawan
LEFT JOIN pemesanan ON wisatawan.id_wisatawan = pemesanan.id_wisatawan
WHERE pemesanan.id_pesan IS NULL
ORDER BY wisatawan.id_wisatawan ASC;

-- soal 4d --
SELECT paket_tur.id_paket, paket_tur.nama_paket
FROM pemesanan
RIGHT JOIN paket_tur ON pemesanan.id_paket = paket_tur.id_paket
WHERE pemesanan.id_pesan IS NULL;

-- soal 5a --
SELECT status, COUNT(id_pesan) AS jumlah_pesanan, SUM(jumlah_orang) AS total_peserta
FROM pemesanan
GROUP BY status
ORDER BY status ASC;

-- soal 5b --
SELECT paket_tur.nama_paket, SUM(paket_tur.harga * pemesanan.jumlah_orang) AS pendapatan
FROM paket_tur
JOIN pemesanan ON paket_tur.id_paket = pemesanan.id_paket
WHERE pemesanan.status = 'Lunas'
GROUP BY paket_tur.id_paket, paket_tur.nama_paket
ORDER BY pendapatan DESC;

-- soal 5c --
SELECT asal_negara, COUNT(id_wisatawan) AS jumlah_wisatawan
FROM wisatawan
GROUP BY asal_negara
ORDER BY jumlah_wisatawan DESC, asal_negara ASC;

-- soal 5d --
SELECT kabupaten, ROUND(AVG(harga_tiket), 2) AS rata_rata, MAX(harga_tiket) AS tertinggi, MIN(harga_tiket) AS terendah
FROM destinasi
GROUP BY kabupaten
ORDER BY rata_rata DESC;

-- soal 5e --
SELECT wisatawan.nama, SUM(pemesanan.jumlah_orang) AS total_peserta
FROM wisatawan
JOIN pemesanan ON wisatawan.id_wisatawan = pemesanan.id_wisatawan
WHERE pemesanan.status = 'Lunas'
GROUP BY wisatawan.id_wisatawan, wisatawan.nama
ORDER BY total_peserta DESC
LIMIT 3;
